class Stack:
    def __init__(self):
        self.element_list = []

    def push(self,element):
        self.element_list.append(element)

    def pop(self):
        return self.element_list.pop()


    def getMax(self):
        sorted_list = sorted(self.element_list)
        return sorted_list[-1]


# stack_obj = Stack()
# stack_obj.push(10)
# stack_obj.push(20)
# stack_obj.push(30)
# stack_obj.push(30)
# print(stack_obj.element_list)
# poped_element = stack_obj.pop()
# print(poped_element)
# max_element = stack_obj.getMax()
# print(max_element)


# Test Data 1 : Vali inpututs
input = [10,20,30,50]
input1 = [-10,10,-10, 0.222]


# Test Data 1 : in Vali inpututs
input = ()
input = {}


import pytest
import unittest
from ddt import ddt, data, file_data, idata, unpack


@ddt
class MyTestCases(unittest.TestCase):

    @data(([1,2,3], 3),
          ([1,2,3], 5))
    @unpack
    def test_pop(self, input, output):
        """Validation Code"""
        self.stack_obj = Stack()
        for i in input:
            self.stack_obj.push(i)
        poped_element = self.stack_obj.pop()
        self.assertEqual(poped_element, output)
